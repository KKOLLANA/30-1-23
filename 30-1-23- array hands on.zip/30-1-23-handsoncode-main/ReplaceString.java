package javapractices;

public class ReplaceString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			String str= " i am  on leave";
			String New_str= str.replace("on", "in");
			
			System.out.println("old String:" +str);
			System.out.println("new String:"+New_str);
	}

}
