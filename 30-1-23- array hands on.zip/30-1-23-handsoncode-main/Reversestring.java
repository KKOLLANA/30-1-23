package javapractices;

public class Reversestring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = " capgemini";
		
		String rev= new StringBuffer(str).reverse().toString();
		System.out.println(str);
		System.out.println(rev);

	}

}
